// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XJOINT_RGB8_PREPARE_H
#define XJOINT_RGB8_PREPARE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xjoint_rgb8_prepare_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XJoint_rgb8_prepare_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XJoint_rgb8_prepare;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XJoint_rgb8_prepare_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XJoint_rgb8_prepare_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XJoint_rgb8_prepare_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XJoint_rgb8_prepare_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XJoint_rgb8_prepare_Initialize(XJoint_rgb8_prepare *InstancePtr, UINTPTR BaseAddress);
XJoint_rgb8_prepare_Config* XJoint_rgb8_prepare_LookupConfig(UINTPTR BaseAddress);
#else
int XJoint_rgb8_prepare_Initialize(XJoint_rgb8_prepare *InstancePtr, u16 DeviceId);
XJoint_rgb8_prepare_Config* XJoint_rgb8_prepare_LookupConfig(u16 DeviceId);
#endif
int XJoint_rgb8_prepare_CfgInitialize(XJoint_rgb8_prepare *InstancePtr, XJoint_rgb8_prepare_Config *ConfigPtr);
#else
int XJoint_rgb8_prepare_Initialize(XJoint_rgb8_prepare *InstancePtr, const char* InstanceName);
int XJoint_rgb8_prepare_Release(XJoint_rgb8_prepare *InstancePtr);
#endif

void XJoint_rgb8_prepare_Start(XJoint_rgb8_prepare *InstancePtr);
u32 XJoint_rgb8_prepare_IsDone(XJoint_rgb8_prepare *InstancePtr);
u32 XJoint_rgb8_prepare_IsIdle(XJoint_rgb8_prepare *InstancePtr);
u32 XJoint_rgb8_prepare_IsReady(XJoint_rgb8_prepare *InstancePtr);
void XJoint_rgb8_prepare_EnableAutoRestart(XJoint_rgb8_prepare *InstancePtr);
void XJoint_rgb8_prepare_DisableAutoRestart(XJoint_rgb8_prepare *InstancePtr);
u32 XJoint_rgb8_prepare_Get_return(XJoint_rgb8_prepare *InstancePtr);

void XJoint_rgb8_prepare_Set_rgb(XJoint_rgb8_prepare *InstancePtr, u64 Data);
u64 XJoint_rgb8_prepare_Get_rgb(XJoint_rgb8_prepare *InstancePtr);
void XJoint_rgb8_prepare_Set_original_q14(XJoint_rgb8_prepare *InstancePtr, u64 Data);
u64 XJoint_rgb8_prepare_Get_original_q14(XJoint_rgb8_prepare *InstancePtr);
void XJoint_rgb8_prepare_Set_d_input_q14(XJoint_rgb8_prepare *InstancePtr, u64 Data);
u64 XJoint_rgb8_prepare_Get_d_input_q14(XJoint_rgb8_prepare *InstancePtr);
void XJoint_rgb8_prepare_Set_cnn_input_q14(XJoint_rgb8_prepare *InstancePtr, u64 Data);
u64 XJoint_rgb8_prepare_Get_cnn_input_q14(XJoint_rgb8_prepare *InstancePtr);
void XJoint_rgb8_prepare_Set_abi_cookie(XJoint_rgb8_prepare *InstancePtr, u32 Data);
u32 XJoint_rgb8_prepare_Get_abi_cookie(XJoint_rgb8_prepare *InstancePtr);

void XJoint_rgb8_prepare_InterruptGlobalEnable(XJoint_rgb8_prepare *InstancePtr);
void XJoint_rgb8_prepare_InterruptGlobalDisable(XJoint_rgb8_prepare *InstancePtr);
void XJoint_rgb8_prepare_InterruptEnable(XJoint_rgb8_prepare *InstancePtr, u32 Mask);
void XJoint_rgb8_prepare_InterruptDisable(XJoint_rgb8_prepare *InstancePtr, u32 Mask);
void XJoint_rgb8_prepare_InterruptClear(XJoint_rgb8_prepare *InstancePtr, u32 Mask);
u32 XJoint_rgb8_prepare_InterruptGetEnabled(XJoint_rgb8_prepare *InstancePtr);
u32 XJoint_rgb8_prepare_InterruptGetStatus(XJoint_rgb8_prepare *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
