// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xjoint_rgb8_prepare.h"

extern XJoint_rgb8_prepare_Config XJoint_rgb8_prepare_ConfigTable[];

#ifdef SDT
XJoint_rgb8_prepare_Config *XJoint_rgb8_prepare_LookupConfig(UINTPTR BaseAddress) {
	XJoint_rgb8_prepare_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XJoint_rgb8_prepare_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XJoint_rgb8_prepare_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XJoint_rgb8_prepare_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XJoint_rgb8_prepare_Initialize(XJoint_rgb8_prepare *InstancePtr, UINTPTR BaseAddress) {
	XJoint_rgb8_prepare_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XJoint_rgb8_prepare_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XJoint_rgb8_prepare_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XJoint_rgb8_prepare_Config *XJoint_rgb8_prepare_LookupConfig(u16 DeviceId) {
	XJoint_rgb8_prepare_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XJOINT_RGB8_PREPARE_NUM_INSTANCES; Index++) {
		if (XJoint_rgb8_prepare_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XJoint_rgb8_prepare_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XJoint_rgb8_prepare_Initialize(XJoint_rgb8_prepare *InstancePtr, u16 DeviceId) {
	XJoint_rgb8_prepare_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XJoint_rgb8_prepare_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XJoint_rgb8_prepare_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

