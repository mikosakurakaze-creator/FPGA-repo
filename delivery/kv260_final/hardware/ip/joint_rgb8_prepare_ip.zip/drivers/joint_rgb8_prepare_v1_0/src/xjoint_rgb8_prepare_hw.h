// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of rgb
//        bit 31~0 - rgb[31:0] (Read/Write)
// 0x1c : Data signal of rgb
//        bit 31~0 - rgb[63:32] (Read/Write)
// 0x20 : reserved
// 0x24 : Data signal of original_q14
//        bit 31~0 - original_q14[31:0] (Read/Write)
// 0x28 : Data signal of original_q14
//        bit 31~0 - original_q14[63:32] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of d_input_q14
//        bit 31~0 - d_input_q14[31:0] (Read/Write)
// 0x34 : Data signal of d_input_q14
//        bit 31~0 - d_input_q14[63:32] (Read/Write)
// 0x38 : reserved
// 0x3c : Data signal of cnn_input_q14
//        bit 31~0 - cnn_input_q14[31:0] (Read/Write)
// 0x40 : Data signal of cnn_input_q14
//        bit 31~0 - cnn_input_q14[63:32] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of abi_cookie
//        bit 31~0 - abi_cookie[31:0] (Read/Write)
// 0x4c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_CTRL            0x00
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_GIE                0x04
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_IER                0x08
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_ISR                0x0c
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_RETURN          0x10
#define XJOINT_RGB8_PREPARE_CONTROL_BITS_AP_RETURN          32
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_RGB_DATA           0x18
#define XJOINT_RGB8_PREPARE_CONTROL_BITS_RGB_DATA           64
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_ORIGINAL_Q14_DATA  0x24
#define XJOINT_RGB8_PREPARE_CONTROL_BITS_ORIGINAL_Q14_DATA  64
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_D_INPUT_Q14_DATA   0x30
#define XJOINT_RGB8_PREPARE_CONTROL_BITS_D_INPUT_Q14_DATA   64
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_CNN_INPUT_Q14_DATA 0x3c
#define XJOINT_RGB8_PREPARE_CONTROL_BITS_CNN_INPUT_Q14_DATA 64
#define XJOINT_RGB8_PREPARE_CONTROL_ADDR_ABI_COOKIE_DATA    0x48
#define XJOINT_RGB8_PREPARE_CONTROL_BITS_ABI_COOKIE_DATA    32

