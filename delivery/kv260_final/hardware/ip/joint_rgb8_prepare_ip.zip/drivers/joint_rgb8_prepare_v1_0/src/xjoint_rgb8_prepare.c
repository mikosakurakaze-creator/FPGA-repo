// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xjoint_rgb8_prepare.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XJoint_rgb8_prepare_CfgInitialize(XJoint_rgb8_prepare *InstancePtr, XJoint_rgb8_prepare_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XJoint_rgb8_prepare_Start(XJoint_rgb8_prepare *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XJoint_rgb8_prepare_IsDone(XJoint_rgb8_prepare *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XJoint_rgb8_prepare_IsIdle(XJoint_rgb8_prepare *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XJoint_rgb8_prepare_IsReady(XJoint_rgb8_prepare *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XJoint_rgb8_prepare_EnableAutoRestart(XJoint_rgb8_prepare *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XJoint_rgb8_prepare_DisableAutoRestart(XJoint_rgb8_prepare *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XJoint_rgb8_prepare_Get_return(XJoint_rgb8_prepare *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XJoint_rgb8_prepare_Set_rgb(XJoint_rgb8_prepare *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_RGB_DATA, (u32)(Data));
    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_RGB_DATA + 4, (u32)(Data >> 32));
}

u64 XJoint_rgb8_prepare_Get_rgb(XJoint_rgb8_prepare *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_RGB_DATA);
    Data += (u64)XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_RGB_DATA + 4) << 32;
    return Data;
}

void XJoint_rgb8_prepare_Set_original_q14(XJoint_rgb8_prepare *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_ORIGINAL_Q14_DATA, (u32)(Data));
    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_ORIGINAL_Q14_DATA + 4, (u32)(Data >> 32));
}

u64 XJoint_rgb8_prepare_Get_original_q14(XJoint_rgb8_prepare *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_ORIGINAL_Q14_DATA);
    Data += (u64)XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_ORIGINAL_Q14_DATA + 4) << 32;
    return Data;
}

void XJoint_rgb8_prepare_Set_d_input_q14(XJoint_rgb8_prepare *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_D_INPUT_Q14_DATA, (u32)(Data));
    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_D_INPUT_Q14_DATA + 4, (u32)(Data >> 32));
}

u64 XJoint_rgb8_prepare_Get_d_input_q14(XJoint_rgb8_prepare *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_D_INPUT_Q14_DATA);
    Data += (u64)XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_D_INPUT_Q14_DATA + 4) << 32;
    return Data;
}

void XJoint_rgb8_prepare_Set_cnn_input_q14(XJoint_rgb8_prepare *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_CNN_INPUT_Q14_DATA, (u32)(Data));
    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_CNN_INPUT_Q14_DATA + 4, (u32)(Data >> 32));
}

u64 XJoint_rgb8_prepare_Get_cnn_input_q14(XJoint_rgb8_prepare *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_CNN_INPUT_Q14_DATA);
    Data += (u64)XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_CNN_INPUT_Q14_DATA + 4) << 32;
    return Data;
}

void XJoint_rgb8_prepare_Set_abi_cookie(XJoint_rgb8_prepare *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_ABI_COOKIE_DATA, Data);
}

u32 XJoint_rgb8_prepare_Get_abi_cookie(XJoint_rgb8_prepare *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_ABI_COOKIE_DATA);
    return Data;
}

void XJoint_rgb8_prepare_InterruptGlobalEnable(XJoint_rgb8_prepare *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_GIE, 1);
}

void XJoint_rgb8_prepare_InterruptGlobalDisable(XJoint_rgb8_prepare *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_GIE, 0);
}

void XJoint_rgb8_prepare_InterruptEnable(XJoint_rgb8_prepare *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_IER);
    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_IER, Register | Mask);
}

void XJoint_rgb8_prepare_InterruptDisable(XJoint_rgb8_prepare *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_IER);
    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XJoint_rgb8_prepare_InterruptClear(XJoint_rgb8_prepare *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJoint_rgb8_prepare_WriteReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_ISR, Mask);
}

u32 XJoint_rgb8_prepare_InterruptGetEnabled(XJoint_rgb8_prepare *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_IER);
}

u32 XJoint_rgb8_prepare_InterruptGetStatus(XJoint_rgb8_prepare *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XJoint_rgb8_prepare_ReadReg(InstancePtr->Control_BaseAddress, XJOINT_RGB8_PREPARE_CONTROL_ADDR_ISR);
}

